var imgURL = chrome.extension.getURL("screenshot.png");
document.getElementById("screenshot").src = imgURL;